﻿using Microsoft.EntityFrameworkCore;
using Proef.veelopveel.core;

namespace Proef.veelopveel.web.Data.Seeding
{
    public static class Seeder
    {
        public static void Seed(ModelBuilder modelBuilder)
        {
            // Students
            modelBuilder.Entity<Student>().HasData(
                new Student { Id = 1, Name = "Alice" },
                new Student { Id = 2, Name = "Bob" },
                new Student { Id = 3, Name = "Charlie" }
            );

            // Courses
            modelBuilder.Entity<Course>().HasData(
                new Course { Id = 1, Title = "Mathematics" },
                new Course { Id = 2, Title = "History" },
                new Course { Id = 3, Title = "Computer Science" }
            );

        }
    }
}
