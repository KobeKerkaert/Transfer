﻿using Microsoft.EntityFrameworkCore;
using Proef.veelopveel.web.Data.Seeding; // namespace waar jouw Seeder staat
using Proef.veelopveel.core;   // namespace waar Student en Course staan

namespace Proef.veelopveel.web.Data
{
    public class SchoolContext : DbContext
    {
        public SchoolContext(DbContextOptions<SchoolContext> options) : base(options)
        {
        }

        // DbSets
        public DbSet<Student> Students { get; set; }
        public DbSet<Course> Courses { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // configureer many-to-many relatie (join table wordt automatisch aangemaakt)
            modelBuilder.Entity<Student>()
            .HasMany(s => s.Courses)
            .WithMany(c => c.Students)
            .UsingEntity<Dictionary<string, object>>(
                    "StudentCourses", // join table naam
                            j => j.HasOne<Course>().WithMany().HasForeignKey("CoursesId"),
                            j => j.HasOne<Student>().WithMany().HasForeignKey("StudentsId"),
                            j =>
            {
                j.HasKey("StudentsId", "CoursesId"); // <-- composite PK
                j.ToTable("StudentCourses");

            // ✅ Seeding join table hier doen
            j.HasData(
                new { StudentsId = 1, CoursesId = 1 },
                new { StudentsId = 1, CoursesId = 3 },
                new { StudentsId = 2, CoursesId = 2 },
                new { StudentsId = 3, CoursesId = 1 },
                new { StudentsId = 3, CoursesId = 2 },
                new { StudentsId = 3, CoursesId = 3 }
            );
        });


            // seeding
            Seeder.Seed(modelBuilder);
        }
    }
}