﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Proef.veelopveel.web.Data;
using Proef.veelopveel.web.ViewModels;

public class SchoolController : Controller
{
    private readonly SchoolContext _context;

    public SchoolController(SchoolContext context)
    {
        _context = context;
    }

    // ✅ Alle vakken van een student
    public IActionResult StudentCourses(int id)
    {
        //om te testen /School/StudentCourses/1
        var student = _context.Students
            .Include(s => s.Courses)
            .FirstOrDefault(s => s.Id == id);

        if (student == null) return NotFound();

        var vm = new StudentCoursesViewModel
        {
            Name = student.Name,
            Courses = student.Courses.Select(c => c.Title).ToList()
        };

        return View(vm);
    }

    // ✅ Alle studenten in een vak
    public IActionResult CourseStudents(int id)
    {
        //om te testen /School/CourseStudents/2
        var course = _context.Courses
            .Include(c => c.Students)
            .FirstOrDefault(c => c.Id == id);

        if (course == null) return NotFound();

        var vm = new CourseStudentsViewModel
        {
            Title = course.Title,
            Students = course.Students.Select(s => s.Name).ToList()
        };

        return View(vm);
    }
}
