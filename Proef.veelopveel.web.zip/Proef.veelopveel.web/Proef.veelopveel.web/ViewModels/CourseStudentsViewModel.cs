﻿namespace Proef.veelopveel.web.ViewModels
{
    public class CourseStudentsViewModel
    {
        public string Title { get; set; }
        public List<string> Students { get; set; }
    }
}
