﻿namespace Proef.veelopveel.web.ViewModels
{
    public class StudentCoursesViewModel
    {
        public string Name { get; set; }
        public List<string> Courses { get; set; }
    }
}
