using Microsoft.EntityFrameworkCore;
using Proef.veelopveel.web.Data; // <-- namespace waar jouw SchoolContext staat

var builder = WebApplication.CreateBuilder(args);

// Connectionstring uit appsettings.json halen
var connectionString = builder.Configuration.GetConnectionString("preof");

// DbContext registreren met SQL Server
builder.Services.AddDbContext<SchoolContext>(options =>
    options.UseSqlServer(connectionString));

// MVC
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
