﻿using ExamenOnlineGokken.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExamenOnlineGokken.ViewModels
{
    public class HomeIndexVM
    {
        public string Title { get; set; }
        public List<Game> Games { get; set; }
    }
}
