﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ExamenOnlineGokken.Models;
using ExamenOnlineGokken.Data;
using ExamenOnlineGokken.ViewModels;
using Microsoft.EntityFrameworkCore;
using ExamenOnlineGokken.Web.ViewModels;
using ExamenOnlineGokken.Domain.Entities;

namespace ExamenOnlineGokken.Controllers
{
    public class HomeController : Controller
    {
        protected GambleDbContext _gambleDbContext;
        public HomeController(GambleDbContext gambleDbContext)
        {
            _gambleDbContext = gambleDbContext;
        }
        public async Task<IActionResult> Index()
        {
            HomeIndexVM homeIndexVM = new HomeIndexVM();
            homeIndexVM.Title = "Upcoming games";
            homeIndexVM.Games = await _gambleDbContext.Games
                .Include(g => g.Bets)
                .ThenInclude(b => b.User).OrderBy(g => g.DateOfGame)
                .ToListAsync();
            return View(homeIndexVM);
        }

       [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public async Task<IActionResult> FindByLeague(int? id)
        {
            var findByLeagueVM = new FindByLeagueVM
            {
                Title = "Games by League",
                SelectedLeagueId = id,
                Games = new List<Game>()
            };

            if (id.HasValue)
            {

                findByLeagueVM.Title = "Games by League";
                var games = await _gambleDbContext.Games //als je andere tabellen wilt kan je includen
                    .Where(g => g.LeagueId == id.Value)
                    .OrderBy(g => g.DateOfGame)
                    .ToListAsync();
                findByLeagueVM.Games = games;
            }
            else
            {
                findByLeagueVM.Title = "Selecteer een League";
            }
            
            return View(findByLeagueVM);
        }

        [HttpGet]
        public async Task<IActionResult> Search()
        {
            var searchVM = new SearchVM();

            searchVM.Leagues = await _gambleDbContext.leagues
                .OrderBy(l => l.Name)
                .ToListAsync();

            return View(searchVM); //ik haal alle leagues op
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Search(SearchVM searchVM)
        {
            // Eerste validatieregel: HomeTeam en AwayTeam mogen niet allebei leeg zijn
            if (string.IsNullOrEmpty(searchVM.HomeTeam) && string.IsNullOrEmpty(searchVM.AwayTeam))
            {
                ModelState.AddModelError(string.Empty, "Home team en Away team mogen niet beide leeg zijn.");
            }

            // Tweedde validatieregel: controleert of het model geldig is (incl. StringLength)
            if (ModelState.IsValid)
            {
                var gamesQuery = _gambleDbContext.Games.AsQueryable();

                if (!string.IsNullOrEmpty(searchVM.HomeTeam))
                {
                    gamesQuery = gamesQuery.Where(g => g.Hometeam.ToLower().Contains(searchVM.HomeTeam.ToLower()));
                }

                if (!string.IsNullOrEmpty(searchVM.AwayTeam))
                {
                    gamesQuery = gamesQuery.Where(g => g.AwayTeam.ToLower().Contains(searchVM.AwayTeam.ToLower()));
                }

                if (searchVM.LeagueId.HasValue)
                {
                    gamesQuery = gamesQuery.Where(g => g.LeagueId == searchVM.LeagueId.Value);
                }

                searchVM.Games = await gamesQuery.OrderBy(g => g.DateOfGame).ToListAsync();
            }

            // Vul de Leagues-lijst opnieuw, zodat de keuzelijst bij een foutmelding niet leeg is
            searchVM.Leagues = await _gambleDbContext.leagues
                                                     .OrderBy(l => l.Name)
                                                     .ToListAsync();

            return View(searchVM);
        }
    }
}
